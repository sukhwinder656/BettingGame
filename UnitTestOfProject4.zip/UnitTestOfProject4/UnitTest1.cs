﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UnitTestOfProject4;

namespace UnitTestOfProject4
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public int Numbergeneration()
        {
            int n = new Random().Next(1,4);
            return n;
        }
    }
}
public class Childclass : UnitTest1
{
    public static void main(String[] args)
    {
        List<int> lister = new List<int>();
        Console.WriteLine("Enter the number of players");
        string p = Console.ReadLine();
        int pl = Convert.ToInt32(p);
        for(int i = 0; i<pl+1 ; i++)
        {
            Console.Write("Enter the dog number from 1 to 3 to bet " + i);
            string val = Console.ReadLine();
            int value = Convert.ToInt32(val);
            lister.Add(value);

        }
        UnitTest1 hiper = new UnitTest1();
        int ra=hiper.Numbergeneration();// code will get the random number
        Console.WriteLine("dog " + ra + "wins the bet");
        for(int i = 0;i< lister.Count; i++)
        {
            if (ra == lister[i])
            {
                if (i == 0)
                {
                    Console.WriteLine("player1 wins");
                }
                if (i == 1)
                {
                    Console.WriteLine("player2 wins");
                }
                if (i == 2)
                {
                    Console.WriteLine("player3 wins");
                }
            }

        }
       
           
        
    }
}
